import React from 'react';

function InvestSales(props){
    return(
        <div>
            Investment product sales data
        </div>
    )
}

export default InvestSales;