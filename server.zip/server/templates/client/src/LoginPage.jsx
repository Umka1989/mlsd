import React from 'react';

function ButtonsBlock(props) {

    let type = props.type;
    let handleswitchFormType = props.handleswitchFormType;

    if (type == 'login') {
        return (
            <div>
                <input type="submit" value="Войти" className='button'></input>
                <button className="button" onClick={handleswitchFormType}>Зарегистрироваться</button>
            </div>)
    } else {
        return (
            <div>
                <input type="submit" value="Зарегистрироваться" className='button'></input>
                <button className="button" onClick={handleswitchFormType}>Я уже зарегистрирован</button>
            </div>
        )
    }
}

function Form(props) {

    let type = props.formType;
    let handleswitchFormType = props.handleswitchFormType;
    let showpasswordConfirmField = type == 'login' ? false : true;

     return (
         <form name="login_form" className="mainPageForm" method="post">
             <input type="text" placeholder="Ваш RB" name="username" autoComplete="username" ></input>
             <input type="password" placeholder="Пароль" name="pswrd"></input>
             {showpasswordConfirmField && <inpupt type="password" placeholder="Пароль" name="pswrdCheck"/>}
             <ButtonsBlock type = {type} handleswitchFormType = {handleswitchFormType}/>
         </form>
     )
}



class LoginPage extends React.Component{
    constructor(props){
        super(props);

        this.state = {
            mistake: null,
            formType: 'login'
        };

        this.switchFormType = this.switchFormType.bind(this);
    }

    switchFormType(event){
        event.preventDefault();
        let existingType = this.state.formType;

        this.setState({
            formType: existingType == 'login' ? 'register': 'login',
        });

        console.log(this.state);

    }

    render(){
            return(
                <Form
                    className="loginForm"
                    formType = {this.state.formType}
                    handleswitchFormType={this.switchFormType}
                />
                )
    }
}

export default LoginPage;
