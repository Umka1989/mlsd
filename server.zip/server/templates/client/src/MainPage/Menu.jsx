import React from 'react';
import styles from './Menu.module.css';

function Menu (props){

    return (
        <ul className={styles.menu}>
            <li>Profile page</li>
            <li>Metrics</li>
            <li>Settings</li>
        </ul>
    )
}


export default Menu