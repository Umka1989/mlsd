import React from 'react';
import styles from './MainContent.module.css'
import {Link} from 'react-router-dom';

function MainContent (props){
    return(
        <nav className = {styles.main}>
                <Link className={styles.link} to='/nbi'>
                    <p>NBI</p>
                    <p>Данные по NBI в вариативных разбивках</p>
                </Link>
                <Link className={styles.link} to='/invest_sales'>
                    <p>Продажи инвест продуктов</p>
                    <p>Данные о продажахинвест продуктов валовые и с учетом коэффицментов</p>
                </Link>
                <Link className={styles.link} to='remainders'>
                    <p>Напоминания</p>
                    <p>Напоминания о днях рождения клиентов, закрытии депозитов, купонных
                        выплатах, погашениях и закрытиях депозитов</p>
                </Link>
                <Link className={styles.link} to='fin_cli'>
                    <p>Финансовые клиенты</p>
                    <p>Данные о портфеле финансовых клиентов и его изменениях за период</p>
                </Link>
                <Link className={styles.link} to='cli_report'>
                    <p>Отчет по портфелю клиента</p>
                    <p>Данные о портфеле клиента на дату
                        Включает состояние портфеля, изменение цены продуктов, данные о купонах и информацию о структурных продуктах</p>
                </Link>
                <Link className={styles.link} to='aum'>
                    <p>AUM</p>
                    <p>
                        Данные по портфелю под управлением
                    </p>
                </Link>
                <Link className={styles.link} to='assets_portfolio'>
                    <p>Остатки на вкладах и счетах</p>
                    <p>
                        Данные по портфелю вкладов и счетов.
                        Крупные оттоки-притоки
                    </p>
                </Link>
        </nav>
    )

}
export default MainContent;
