import React from 'react';
import styles from './FinClients/FinClients.module.css';

function FinClients(props){
    return(
        <div>
            <div>Grafic</div>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>Управляющий директор</th>
                        <th>Портфель клиентов</th>
                        <th>Изменение за квартал</th>
                        <th>Изменение за год</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Афанасьев Александр</td>
                        <td>100</td>
                        <td>-3</td>
                        <td>5</td>
                    </tr>
                    <tr>
                        <td>Буренко Валерия</td>
                        <td>100</td>
                        <td>-3</td>
                        <td>5</td>
                    </tr>
                    <tr>
                        <td>Воробьева Анна</td>
                        <td>100</td>
                        <td>-3</td>
                        <td>5</td>
                    </tr>
                    <tr>
                        <td>Миронин Дмитрий</td>
                        <td>100</td>
                        <td>-3</td>
                        <td>5</td>
                    </tr>
                    <tr>
                        <td>Озерова Юлия</td>
                        <td>100</td>
                        <td>-3</td>
                        <td>5</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

export default FinClients;