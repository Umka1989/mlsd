import React from 'react';

function Remainders(props){
    return(
        <div>
            Task board
        </div>
    )
}

export default Remainders;