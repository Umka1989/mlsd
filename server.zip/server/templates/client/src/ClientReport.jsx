import React from 'react';
import FindClient from "./ClientReport/FindClient";
import Report from "./ClientReport/Report";

class ClientReport extends React.Component{

    constructor(props) {
        super(props);

        this.state = {
            client_found: true,
            search_type: 'full_name',
            client_list: [],
             show_found_clients: false,
            mistake: undefined,
            formValue: '',
            currency: 'RUB',
            data: {
                clientInfo:{
                    full_name: 'Чехов Антон Павлович',
                    client_number: '999999STL',
                    report_date: '24.03.1987'
                },
                totals: {
                    currencies: {
                        USD: {
                            amt: 'amt_usd',
                            USD: 'eqv_usd',
                            RUB: 'eqv_rub',
                            EUR: 'eqv_eur'
                        },
                        RUB: {
                            amt: 'amt_rub',
                            USD: 'eqv_usd',
                            RUB: 'eqv_rub',
                            EUR: 'eqv_eur'
                        },
                        EUR: {
                            amt: 'amt_eur',
                            USD: 'eqv_usd',
                            RUB: 'eqv_rub',
                            EUR: 'eqv_eur'
                        }
                    },
                    products:{
                        deposits:{
                            EUR: 'eur_sum_depos',
                            RUB: 'rub_sum_depos',
                            USD: 'usd_sum_depos'
                        },
                        savings:{
                            EUR: 'eur_sum_savings',
                            RUB: 'rub_sum_savings',
                            USD: 'usd_sum_savings'
                        },
                        current:{
                            EUR: 'eur_sum_current',
                            RUB: 'rub_sum_current',
                            USD: 'usd_sum_current'
                        }
                    }
                },
                products_data:{
                    deposits:[
                        {
                            name:'Вклад Lhermitage',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            length_: 2,
                            close_date: '12.03.2022',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Вклад монблан',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            length_: 2,
                            close_date: '12.03.2022',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name: '150 лет надежности',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            length_: 2,
                            close_date: '12.03.2022',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                savingAccounts:[
                        {
                            name:'Сберегательный счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Сберегательный счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Сберегательный счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                currentAccounts:[
                        {
                            name:'Текущий счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Текущий счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Текущий счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                metallAccounts:[
                        {
                            name:'Металлический счет',
                            currency: 'Au',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        }
                    ],
                brockAccounts:[
                        {
                            name:'Брокерский счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Брокерский счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Брокерский счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                    securities: [
                    {
                        issuer: 'Rosbank',
                        isin: '2358FGH356',
                        currency: 'RUB',
                        indPrice: '105.3',
                        countOfSecurities: 36,
                        amt: 230000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    },
                    {
                        issuer: 'SG group',
                        isin: '2358FGH563',
                        currency: 'EUR',
                        indPrice: '102.6',
                        countOfSecurities: 133,
                        amt: 250000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    }
                ],
                funds: [
                    {
                        issuer: 'Rosbank',
                        isin: '2358FGH356',
                        currency: 'RUB',
                        indPrice: '105.3',
                        countOfSecurities: 36,
                        amt: 230000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    },
                    {
                        issuer: 'SG group',
                        isin: '2358FGH563',
                        currency: 'EUR',
                        indPrice: '102.6',
                        countOfSecurities: 133,
                        amt: 250000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    }
                ],
                strProducts: [
                    {
                        issuer: 'SG ISSUER',
                        isin: '2358FGH356',
                        currency: 'RUB',
                        indPrice: '105.3',
                        countOfSecurities: 36,
                        amt: 230000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    },
                    {
                        issuer: 'SG ISSUER',
                        isin: '2358FGH563',
                        currency: 'EUR',
                        indPrice: '102.6',
                        countOfSecurities: 133,
                        amt: 250000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    }
                ],
                bonds: [
                    {
                        issuer: 'BONDS ISSUER',
                        isin: '2358FGH356',
                        currency: 'RUB',
                        indPrice: '105.3',
                        marginality: '2.2',
                        countOfSecurities: 36,
                        amt: 230000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    },
                    {
                        issuer: 'BONDS ISSUER',
                        isin: '2358FGH356',
                        currency: 'RUB',
                        indPrice: '105.3',
                        marginality: '2.2',
                        countOfSecurities: 36,
                        amt: 230000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    }
                ],
                    ili: [
                    {
                        provider: 'SGI',
                        strategy: 'инвестиции в будущее',
                        currency: 'RUB',
                        openDate: '23-12-2017',
                        length_: '5.0',
                        closeDate: '23-06-2021',
                        amt: 23000000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    },
                    {
                        provider: 'ЭРГО',
                        strategy: 'инвестиции в прошлое',
                        currency: 'EUR',
                        openDate: '23-12-2017',
                        length_: '5.0',
                        closeDate: '23-06-2021',
                        amt: 100000.00,
                        RUB: 'eqv_rub',
                        USD: 'eqv_usd',
                        EUR: 'eqv_eur',
                        partition: '3.75 %'
                    }
                ],
                }
        }}

        this.handleSwitchFormType = this.handleSwitchFormType.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        this.findClient = this.findClient.bind(this);
        this.handleChangeCurrency = this.handleChangeCurrency.bind(this);
    }

    handleSwitchFormType(event){
        this.setState({
            search_type: event.target.value,
        });
    }

    handleChangeCurrency(event){
        this.setState({
            currency: event.target.value,
        });
    }

     findClient(event) {
        fetch('http://127.0.0.1:5000/find_client', {
                method: 'get',
                mode: 'no-cors'
            }).then(response => {
                console.log( response.json());
            })
      }

    handleInputChange(event){
        this.setState({
            formValue: event.target.value,
        });
    }



    render() {
        let component;
        if (this.state.client_found){
            component = <Report
                data = {this.state.data}
                currency = {this.state.currency}
                changeCurrency = {this.handleChangeCurrency}
                productTotals = {this.state.data.totals.products}
                currenciesTotals = {this.state.data.totals.currencies}
            />
        } else {
            component = <FindClient
                clients = {this.state.client_list}
                type={ this.state.search_type}
                show_flag={this.state.show_found_clients}
                changeFormType = {this.handleSwitchFormType}
                mistake = {this.state.mistake}
                value = {this.state.value}
                changeInputValue = {this.handleInputChange}
                find = {this.findClient}
                client_list = {this.state.client_list}
            />
        };

        return (component);
    }
}

export default ClientReport;