import React from 'react';
import styles from './Report.module.css'

function TotalBlock(props){

    let header;
    let tableDataRows= [];
    let srcData = props.data;
    console.log('total src data');
    console.log(srcData);
    let currency = props.currency;
    let class_name;
    if (props.tableType == 'productsTable') {
        class_name = styles.rightBlock;
    } else {
        class_name = styles.leftBlock;
    }


    const product_dict = {
        deposits: 'Депозиты',
        savings: 'Сберегательные счета',
        current: 'Текущие счета'
    };

    if (props.tableType == 'productsTable') {
        header = (
            <thead>
            <tr><th colSpan={2}>Разбивка по  продуктам</th></tr>
            <tr>
                <th>Название продукта</th>
                <th>Сумма в эквиваленте</th>
            </tr>
            </thead>
            );
        } else {
            header = (
                <thead>
                <tr><th colSpan={3}>Разбивка по валютам</th></tr>
                <tr>
                    <th>Валюта</th>
                    <th>Сумма в валюте</th>
                    <th>Сумма в эквиваленте</th>
                </tr>
                </thead>
            );
        }
        if (props.tableType == 'productsTable') {
            for (const[key, value] of Object.entries(srcData)){
                tableDataRows.push(
                    <tr key={key}>
                        <td>{product_dict[key]}</td>
                        <td>{value[props.currency]}</td>
                    </tr>)
            }
        } else {
            for(const[key, value] of Object.entries(srcData)){
                tableDataRows.push(
                <tr key={key}>
                    <td>{key}</td>
                    <td>{value['amt']}</td>
                    <td>{value[currency]}</td>
                </tr>)
            }
        }

    return(
        <div className={class_name}>
            <table className={styles.table}>
                {header}
                <tbody>
                    {tableDataRows}
                </tbody>
            </table>
        </div>
    )
}
export default TotalBlock;