import React from 'react';
import styles from './Report.module.css';

function Bonds(props){

    let currency = props.currency;
    let bondsList = [];

    props.data.forEach((each, index) =>{
        bondsList.push(
            <tr key ={index}>
                <td>{each['issuer']}</td>
                <td>{each['isin']}</td>
                <td>{each['currency']}</td>
                <td>{each['indPrice']}</td>
                <td>{each['marginality']}</td>
                <td>{each['countOfSecurities']}</td>
                <td>{each['amt']}</td>
                <td>{each[currency]}</td>
                <td>{each['partition']}</td>
            </tr>
        )
    })

    return(
        <div>
                <div>Облигации</div>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Наименование инструмента</th>
                            <th>ISIN</th>
                            <th>Валюта</th>
                            <th>Индикативная цена</th>
                            <th>Доходность, % годовых</th>
                            <th>Количество бумаг</th>
                            <th>Сумма с НКД</th>
                            <th>Сумма с НКД, эквивалент</th>
                            <th>Доля в общем портфеле</th>
                        </tr>
                    </thead>
                    <tbody>
                        {bondsList}
                    </tbody>
                </table>
            </div>
    )
}

export default Bonds;