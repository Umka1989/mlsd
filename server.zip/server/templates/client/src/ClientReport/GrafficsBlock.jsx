import React from 'react';
import styles from './Report.module.css'

function GrafficsBlock(props){
    return(
        <div className={styles.graffics}>
            GrafficsBlock
        </div>
    )
}

export default GrafficsBlock;