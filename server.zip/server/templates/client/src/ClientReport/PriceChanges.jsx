import React from "react";

function PriceChanges(props){

    return(
        <div>
            Изменение цен инвестиционных продуктов
            <table>
                <thead>
                    <tr>
                        <th>Наименование инструмента</th>
                        <th>Валюта</th>
                        <th>Индикативная цена</th>
                        <th>Количество бумаг</th>
                        <th>Сумма</th>
                        <th>Эквивалент</th>
                        <th>Цена покупки</th>
                        <th>Дата покупки</th>
                        <th>Изменение цены</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Наименование</td>
                        <td>Рубли</td>
                        <td>100</td>
                        <td>100</td>
                        <td>10000</td>
                        <td>10000</td>
                        <td>99</td>
                        <td>21.11.2012</td>
                        <td>-1 %</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

export default PriceChanges;