import React from 'react';
import styles from './Report.module.css';


function Accounts(props){
    let header;

    switch(props.type_){
        case 'current':
           header = 'Текущие счета';
           break;
        case 'saving':
           header = 'Сберегательные счета';
           break;
        case 'metall':
            header = 'Металические счета';
            break;
        case 'brock':
            header = 'Брокерские счета';
            break;
    }

    let currency = props.currency;


    let accountsList = [];

    props.data.forEach((each, index) =>{
        accountsList.push(
            <tr key ={index}>
                <td>{each['name']}</td>
                <td>{each['currency']}</td>
                <td>{each['marginality']}</td>
                <td>{each['openDate']}</td>
                <td>{each['amt']}</td>
                <td>{each[currency]}</td>
                <td>{each['partition']}</td>
            </tr>
        )
    })

    return(
        <div>
        <div>{header}</div>
            <table className={styles.table}>
                <thead>
                <tr>
                    <th>Название вклада</th>
                    <th>Валюта</th>
                    <th>Доходность в %</th>
                    <th>Дата открытия</th>
                    <th>Сумма в валюте номинала</th>
                    <th>Сумма в эквиваленте</th>
                    <th>Доля в общем портфеле</th>
                </tr>
                </thead>
                <tbody>
                    {accountsList}
                </tbody>
            </table>
        </div>
    )
}

export default Accounts;