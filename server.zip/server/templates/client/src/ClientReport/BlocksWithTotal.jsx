import React from 'react';

function BlocksWithTotal(props) {


}



const tableType = props.tableType;
        const srcData = props.srcData;
        const tableClassName = (tableType == 'productsTable') ? "productsTable" : "currenciesTable";

        let tableDataRows = [];
        let header;

        if (tableType == 'productsTable') {
            header = (
                <thead>
                 <tr>
                    <th colSpan={2}>Разбивка по  продуктам</th>
                </tr>
                <tr>
                    <th>Название продукта</th>
                    <th>Сумма в эквиваленте</th>
                </tr>
                </thead>
            );
        } else {
            header = (
                <thead>
                <tr>
                    <th colSpan={3}>Разбивка по валютам</th>
                </tr>
                <tr>
                    <th>Валюта</th>
                    <th>Сумма в валюте</th>
                    <th>Сумма в эквиваленте</th>
                </tr>
                </thead>
            );
        }

        if (tableType == 'productsTable') {

            srcData.forEach((each) => {
                tableDataRows.push(<tr key={each[0]}><td>{each[0]}</td>
                    <td>{each[1].toLocaleString('ru-RU', { maximumFractionDigits: 2, minimumFractionDigits:2})  }</td></tr>)
            })
        } else {
            srcData.forEach((each) => {
                tableDataRows.push(<tr key={each[0]}><td>{each[0]}</td><td>{each[1].toLocaleString('ru-RU', { maximumFractionDigits: 2, minimumFractionDigits:2})}</td><td>{each[2].toLocaleString('ru-RU', { maximumFractionDigits: 2, minimumFractionDigits:2})}</td></tr>)
            })
        }

        return (
            <table className = {tableClassName}>
                {header}
                <tbody>
                    {tableDataRows}
                </tbody>
            </table>
        )