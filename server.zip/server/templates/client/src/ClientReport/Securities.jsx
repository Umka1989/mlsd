import React from 'react';
import styles from './Report.module.css';

function Securities(props){

    let currency = props.currency;
    let securitiesList = [];

    props.data.forEach((each, index) =>{
        securitiesList.push(
            <tr key ={index}>
                <td>{each['issuer']}</td>
                <td>{each['isin']}</td>
                <td>{each['currency']}</td>
                <td>{each['indPrice']}</td>
                <td>{each['countOfSecurities']}</td>
                <td>{each['amt']}</td>
                <td>{each[currency]}</td>
                <td>{each['partition']}</td>
            </tr>
        )
    })

    return(
        <div>
                <div>Акции</div>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Наименование инструмента</th>
                            <th>ISIN</th>
                            <th>Валюта</th>
                            <th>Индикативная цена</th>
                            <th>Количество бумаг</th>
                            <th>Сумма</th>
                            <th>Сумма, эквивалент</th>
                            <th>Доля в общем портфеле</th>
                        </tr>
                    </thead>
                    <tbody>
                        {securitiesList}
                    </tbody>
                </table>
            </div>
    )
}

export default Securities;