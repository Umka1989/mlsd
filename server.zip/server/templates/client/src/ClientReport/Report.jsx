import React from 'react';
import ReportHeader from "./ReportHeader";
import ClientInfoBlock from './ClientInfoBlock';
import CurrencyPicker from './CurrencyPicker';
import GrafficsBlock from './GrafficsBlock';
import TotalBlock from "./TotalBlock";
import Deposits from './Deposits';
import Accounts from "./Accounts";
import Securities from './Securities';
import StrProducts from './StrProducts';
import Bonds from "./Bonds";
import ILI from './ILI';
import PriceChanges from './PriceChanges';
import Funds from './Funds';
import StrProductsAdditionalInfo from './StrProductsAdditionalInfo';
import CouponCalendar from './CouponCalendar';

import styles from './Report.module.css';

function Report (props){

    const deposits_flag = 'deposits' in props.data.products_data ? true: false;
    const savingAccs_flag = 'savingAccounts' in props.data.products_data ? true: false;
    const currentAccs_flag = 'currentAccounts' in props.data.products_data ? true: false;
    const metallAccs_flag = 'metallAccounts' in props.data.products_data ? true: false;
    const brockAccs_flag = 'brockAccounts' in props.data.products_data ? true: false;
    const securities_flag = 'securities' in props.data.products_data ? true: false;
    const strProd_flag = 'strProducts' in props.data.products_data ? true: false;
    const bonds_flag = 'bonds' in props.data.products_data ? true: false;
    const ili_flag = 'ili' in props.data.products_data ? true: false;
    const funds_flag = 'funds' in props.data.products_data ? true: false;
    const invest = securities_flag || bonds_flag || funds_flag;

    return(
        <div className={styles.body}>
            <ReportHeader />
            <div className='clearFix'></div>
            <div className={styles.general}>
                <div className={styles.leftBlock}>
                <ClientInfoBlock

                    data={props.data.clientInfo}
                />
                </div>
                <div className={styles.rightBlock}>
                <CurrencyPicker
                    className={styles.currencyPicker}
                    currency={props.currency}
                    changeCurrency={props.changeCurrency}
                />
                </div>
            </div>
            <div className='clearFix'></div>
            <GrafficsBlock />
            <div className={styles.graffics}>
                <TotalBlock
                    tableType ='currenciesTable'
                    currency = {props.currency}
                    data = {props.currenciesTotals}
                />
                <TotalBlock
                    tableType='productsTable'
                    currency = {props.currency}
                    data = {props.productTotals}
                />
            </div>
            <div className='clearFix'></div>
            {deposits_flag && <Deposits
                currency={ props.currency}
                data={ props.data.products_data.deposits}
            />}
            {currentAccs_flag && <Accounts
                type_= 'current'
                currency={props.currency}
                data={props.data.products_data.currentAccounts}
            />}
            {savingAccs_flag && <Accounts
                type_= 'saving'
                currency={props.currency}
                data={props.data.products_data.savingAccounts}
            />}
            {metallAccs_flag && <Accounts
                type_= 'metall'
                currency={props.currency}
                data={props.data.products_data.metallAccounts}
            />}
            {brockAccs_flag && <Accounts
                type_= 'brock'
                currency={props.currency}
                data={props.data.products_data.brockAccounts}
            />}
            {securities_flag && <Securities
                currency={props.currency}
                data={props.data.products_data.securities}
            />}
            {funds_flag && <Funds
                currency={props.currency}
                data={props.data.products_data.funds}
            />}
            {bonds_flag && <Bonds
                currency={props.currency}
                data={props.data.products_data.bonds}
            />}
            {strProd_flag && <StrProducts
                currency={props.currency}
                data={props.data.products_data.strProducts}
            />}
            {ili_flag && <ILI
                currency={props.currency}
                data={props.data.products_data.ili}
            />}
            {funds_flag && <PriceChanges/>}
            <StrProductsAdditionalInfo />
            <CouponCalendar />

        </div>
    )
}

export default Report;