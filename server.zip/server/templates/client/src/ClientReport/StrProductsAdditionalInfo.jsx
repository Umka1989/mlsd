import React from "react";
import styles from './Report.module.css';

function StrProductsAdditionalInfo(props){
    return(
        <div>
            <div>Дополнительные данные о структурных продуктах</div>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>ISIN</th>
                        <th>Эмитент</th>
                        <th>Валюта</th>
                        <th>Фиксация транша</th>
                        <th>Погашение</th>
                        <th>Купон (% годовых)</th>
                        <th>Купонный барьер</th>
                        <th>Защитный барьер</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ISIN</td>
                        <td>SG ISSUER</td>
                        <td>RUB</td>
                        <td>22.01.2019</td>
                        <td>21.01.2021</td>
                        <td>30 %</td>
                        <td>75 %</td>
                        <td>60 %</td>
                    </tr>
                </tbody>
            </table>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>Эмитент</th>
                        <th>Цена покупки</th>
                        <th>Текущая цена</th>
                        <th>Купонный барьер</th>
                        <th>Дистанция до барьера</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Issuer</td>
                        <td>100</td>
                        <td>99</td>
                        <td>75 %</td>
                        <td>25 %</td>
                    </tr>
                    <tr>
                        <td>Issuer</td>
                        <td>100</td>
                        <td>99</td>
                        <td>75 %</td>
                        <td>25 %</td>
                    </tr>
                    <tr>
                        <td>Issuer</td>
                        <td>100</td>
                        <td>99</td>
                        <td>75 %</td>
                        <td>25 %</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

export default StrProductsAdditionalInfo;