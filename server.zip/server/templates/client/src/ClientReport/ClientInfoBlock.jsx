import React from 'react';
import styles from './ClientInfoBlock.module.css';

function ClientInfoBlock(props){

    return(
            <table className={styles.table}>
                <tbody>
                    <tr>
                        <td>Портфель клиента</td>
                        <td>{props.data.full_name}</td>
                    </tr>
                    <tr>
                        <td>Клиентский номер</td>
                        <td>{props.data.client_number}</td>
                    </tr>
                    <tr>
                        <td>Дата отчёта</td>
                        <td>{props.data.report_date}</td>
                    </tr>
                    {console.log(props)}
                </tbody>
            </table>
        )
    }


export default ClientInfoBlock;