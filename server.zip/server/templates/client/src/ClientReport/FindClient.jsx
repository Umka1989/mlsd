import React from 'react';
import styles from './ClientReport.module.css';
import FoundClientsList from "./FoundClientsList";

function FindClient(props){

    const activeClass = styles.active_find_parametr;
    const inactiveClass = styles.inactive_find_parametr;

    return(
        <div>
            <div>
                <button
                    className={props.type == 'full_name'? activeClass : inactiveClass}
                    onClick={props.changeFormType}
                    value='full_name'
                >ФИО</button>
                <button
                    className={props.type == 'bis_id'? activeClass : inactiveClass}
                    onClick={props.changeFormType}
                    value='bis_id'
                >БИС ID</button>
                <button
                    className={props.type == 'siebel_id'? activeClass : inactiveClass}
                    onClick={props.changeFormType}
                    value='siebel_id'
                >Siebel ID</button>
                <button
                    className={props.type == 'abs_id'? activeClass : inactiveClass}
                    onClick={props.changeFormType}
                    value='abs_id'
                >ABS ID</button>
            </div>
            <input type='text' value = {props.value} onChange={props.changeInputValue}/>

            {props.show_flag && <FoundClientsList client_list={props.client_list}/>}

            <button onClick={props.find}>Выбрать</button>
        </div>
    )

}
export default FindClient;