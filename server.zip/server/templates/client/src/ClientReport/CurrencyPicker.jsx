import React from 'react';
import styles from "./ClientReport.module.css";

function CurrencyPicker (props){

    const activeClass = styles.active_find_parametr;
    const inactiveClass = styles.inactive_find_parametr;

    return(
        <div>
            <div>Выберете валюту отчета</div>
            {console.log(props)}
            <div>
                <button
                    className={props.currency == 'RUB'? activeClass : inactiveClass}
                    onClick={props.changeCurrency}
                    value='RUB'
                >RUB</button>
                <button
                    className={props.currency == 'USD'? activeClass : inactiveClass}
                    onClick={props.changeCurrency}
                    value='USD'
                >USD</button>
                <button
                    className={props.currency == 'EUR'? activeClass : inactiveClass}
                    onClick={props.changeCurrency}
                    value='EUR'
                >EUR</button>
            </div>
        </div>
    )
}

export default CurrencyPicker;