import React from 'react';

function FoundClientsList(props){
    let client_list = props.client_list;

    let component;
    if (client_list.length == 0 ){
        component = <div></div>
    } else {
        component = <div>Found Clients List</div>
    }

    return(component)

}

export default FoundClientsList;