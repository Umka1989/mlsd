import React from 'react';
import styles from './Report.module.css';

function Deposits(props){
    let depositsList = [];
    let currency = props.currency;

    props.data.forEach((each, index) =>{
        depositsList.push(
            <tr key ={index}>
                <td>{each['name']}</td>
                <td>{each['currency']}</td>
                <td>{each['marginality']}</td>
                <td>{each['openDate']}</td>
                <td>{each['length_']}</td>
                <td>{each['close_date']}</td>
                <td>{each['amt']}</td>
                <td>{each[currency]}</td>
                <td>{each['partition']}</td>
            </tr>
        )
    })

    return(
        <div>
        <div>Депозиты</div>
            <table className={styles.table}>
                <thead>
                <tr>
                    <th>Название вклада</th>
                    <th>Валюта</th>
                    <th>Доходность в %</th>
                    <th>Дата открытия</th>
                    <th>Срок истечения в годах</th>
                    <th>Дата закрытия</th>
                    <th>Сумма в валюте номинала</th>
                    <th>Сумма в эквиваленте</th>
                    <th>Доля в общем портфеле</th>
                </tr>
                </thead>
                <tbody>
                    {depositsList}
                </tbody>
            </table>
        </div>
    )
}

export default Deposits;