import React from 'react';
import rosbankLogo from '../images/future_is_you.svg';
import lhermitageImg from '../images/lhermitage_logo.png';
import styles from './ReporttHeader.module.css';

function ReportHeader(props){
    return(
            <div>
                <img src={rosbankLogo} className={styles.rosbankLogo}></img>
                <h1 className={styles.header}>Инвестиционный портфель</h1>
                <img src={lhermitageImg} className={styles.logoLhermitage}></img>
            </div>
        )
}

export default ReportHeader;