import React from 'react';
import styles from './Report.module.css';

function ILI(props){

    let currency = props.currency;

    let ILIList = [];

    props.data.forEach((each, index) =>{
        ILIList.push(
            <tr key ={index}>
                <td>{each['provider']}</td>
                <td>{each['strategy']}</td>
                <td>{each['currency']}</td>
                <td>{each['openDate']}</td>
                <td>{each['length_']}</td>
                <td>{each['closeDate']}</td>
                <td>{each['amt']}</td>
                <td>{each[currency]}</td>
                <td>{each['partition']}</td>
            </tr>
        )
    })

    return(
        <div>
        <div>ИСЖ</div>
            <table className={styles.table}>
                <thead>
                <tr>
                    <th>Провайдер</th>
                    <th>Стратегия</th>
                    <th>Валюта</th>
                    <th>Дата открытия</th>
                    <th>Срок до истечения в годах</th>
                    <th>Дата закрытия</th>
                    <th>Сумма в валюте номинала</th>
                    <th>Сумма в эквиваленте</th>
                    <th>Доля в общем портфеле</th>
                </tr>
                </thead>
                <tbody>
                    {ILIList}
                </tbody>
            </table>
        </div>
    )
}

export default ILI;