import React from 'react';

function CouponCalendar(props){
    return(
        <div>
            <table>
                <caption>Coupon calendar on 99999</caption>
                <thead>
                    <tr>
                        <td>Number</td>
                        <td>Start date</td>
                        <td>Plan date</td>
                        <td>Pay date</td>
                        <td>Percent</td>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    )
}

export default CouponCalendar;