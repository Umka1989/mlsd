import React from 'react';

function Footer (props){
    return(
        <div>LHermitage digital team</div>
    )
}

export default Footer;