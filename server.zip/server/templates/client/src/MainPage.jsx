import React from 'react';
import Header from "./Header";
import Menu from "./MainPage/Menu";
import MainContent from "./MainPage/MainContent";
import Footer from "./Footer";
import styles from './MainPage/MainPage.module.css';

class MainPage extends React.Component{
    constructor(props) {
        super(props);

        this.state = {
            imgPath: './images/photos/photo.jpg',
        }
    }
    render(){
        return(
            <div>
                <Header imgPath = {this.state.imgPath}/>
                <div className={styles.mainBlock}>
                    <Menu/>
                    <MainContent/>
                </div>
                <div className = {styles.clearfix}></div>
                <Footer/>
            </div>
        )
}
}



export default MainPage;
