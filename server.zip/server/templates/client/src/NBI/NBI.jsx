import React from "react";

class  NBI extends React.Component {
    constructor(props){

        super(props);

        this.state ={
            data:{
                monthes:[]
            }
        }
    }
    render() {
        return (
            <div>
                <div>
                    <div>
                        <div>Выбор типа отчета</div>
                        <div>
                            <button>План-факт</button>
                            <button>Общие данные</button>
                        </div>
                    </div>
                    <div>
                        <div>Выбор периода</div>
                        <div>
                            <div>
                                <div>Месяц</div>
                                <div>
                                    <button>Январь</button>
                                    <button>Февраль</button>
                                    <button>Март</button>
                                    <button>Апрель</button>
                                    <button>Май</button>
                                </div>
                            </div>
                            <div>
                                <div>Квартал</div>
                                <div>
                                    <button>Первый квартал</button>
                                    <button>Второй квартал</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        )
    }
}

export default NBI;