import React from 'react';

function Test1 (props){
    return(
        <div>
            Test ONE
        </div>
    )
}

export default Test1;