import React from 'react';
import styles from './Header.module.css';
import imgSrc from './images/lhermitage_logo.png'

function Header(props){
    return(
        <div className={styles.border}>
            <div className={styles.stuffInfo}>
                <img src={props.imgPath} alt='your Photo'/>
                <div className={styles.stuffName}>My name</div>
            </div>
            <div>
                <img className={styles.lhermitageLogo} src={imgSrc} alt='L`hermitage logo'/>
            </div>
            <div className='clearFix'></div>
        </div>
    )
}

export default Header;