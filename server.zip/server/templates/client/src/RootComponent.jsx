import React from 'react';
import {BrowserRouter, Route, Switch} from "react-router-dom";
import LoginPage from "./LoginPage";
import PrivateRoute from "./PrivateRoute";
import MainPage from "./MainPage";
import NotFoundPage from "./NotFoundPage";
import NBI from './NBI/NBI';
import FinClients from "./FinClients";
import ClientReport from "./ClientReport";
import Remainders from './Remainders';
import InvestSales from "./InvestSales";
import AUM from './AUM';
import AssetsPortfolio from "./AssetsPortfolio";


class RootComponent extends React.Component{

    constructor(props){
        super(props);

         this.state = {
             is_loggined: true,

        };
        this.handleLogin = this.handleLogin.bind(this)
    }

    handleLogin(event){
        let current_flag = this.state.is_loggined;

        this.setState({
            is_loggined: current_flag == false ? true : false,
        })
    }

    render(){
        return(
            <BrowserRouter>
                <Switch>
                    <Route  path={'/login'} component={LoginPage}></Route>
                    <PrivateRoute exact authed={this.state.is_loggined} path='/remainders' component={Remainders} />
                    <PrivateRoute exact authed={this.state.is_loggined} path='/' component={MainPage}/>
                    <PrivateRoute exact authed={this.state.is_loggined} path='/nbi' component={NBI} />
                    <PrivateRoute exact authed={this.state.is_loggined} path='/fin_cli' component={FinClients} />
                    <PrivateRoute exact authed={this.state.is_loggined} path='/cli_report' component={ClientReport} />
                    <PrivateRoute exact authed={this.state.is_loggined} path='/invest_sales' component={InvestSales}/>
                    <PrivateRoute exact authed={this.state.is_loggined} path='/aum' component={AUM}/>
                    <PrivateRoute exact authed={this.state.is_loggined} path='/assets_portfolio' component={AssetsPortfolio}/>
                    <Route component={NotFoundPage}></Route>
                </Switch>
            </BrowserRouter>
        )
    }
}

export default RootComponent;

