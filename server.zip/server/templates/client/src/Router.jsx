import React from 'react';
import MainPage from "./MainPage";
import NBI from "./MainPage/NBIcomponent/NBI";
import {Route, Switch} from 'react-router-dom';
import LoginPage from "./LoginPage";
import PrivateRoute from "./PrivateRoute";


class Router extends React.Component{

    constructor(props){
        super(props);

         this.state = {
            is_loggined: true,
        };
        this.handleLogin = this.handleLogin.bind(this)
    }

    handleLogin(event){
        let current_flag = this.state.is_loggined;

        this.setState({
            is_loggined: current_flag == false ? true : false,
        })
    }
    render(){
        return(

    )
    }

}

export default Router;