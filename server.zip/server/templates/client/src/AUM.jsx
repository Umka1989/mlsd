import React from 'react';

function AUM (props){
    return(
        <div>
            AUM
        </div>
    )
}
export default AUM;