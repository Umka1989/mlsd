import React from 'react';

function NotFoundPage(props){
    return(
        <div>
            Извините, но такой страницы нет
        </div>
    )
}

export default NotFoundPage;