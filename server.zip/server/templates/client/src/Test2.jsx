import React from 'react';

function Test2 (props){
    return(
        <div>
            Test TWO
        </div>
    )
}

export default Test2;