let state = {
            client_found: true,
            search_type: 'full_name',
            client_list: [],
            data: {
                clientInfo:{
                    full_name: 'Чехов Антон Павлович',
                    client_number: '999999STL',
                    report_date: '24.03.1987'
                },
                totals: {
                    currencies: {
                        USD: {
                            amt: 'amt_usd',
                            eqv: 'eqv_usd'
                        },
                        RUB: {
                            amt: 'amt_rub',
                            eqv: 'eqv_rub'
                        },
                        EUR: {
                            amt: 'amt_eur',
                            eqv: 'eqv_eur'
                        }
                    },
                    products:{
                        deposits:{
                            EUR: 'eur_sum_depos',
                            RUB: 'rub_sum_depos',
                            USD: 'usd_sum_depos'
                        },
                        savings:{
                            EUR: 'eur_sum_savings',
                            RUB: 'rub_sum_savings',
                            USD: 'usd_sum_savings'
                        },
                        current:{
                            EUR: 'eur_sum_current',
                            RUB: 'rub_sum_current',
                            USD: 'usd_sum_current'
                        }
                    }
                },
                products_data:{
                    deposits:[
                        {
                            name:'Вклад Lhermitage',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            length_: 2,
                            close_date: '12.03.2022',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Вклад монблан',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            length_: 2,
                            close_date: '12.03.2022',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name: '150 лет надежности',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            length_: 2,
                            close_date: '12.03.2022',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                savingAccounts:[
                        {
                            name:'Сберегательный счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Сберегательный счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Сберегательный счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                currentAccounts:[
                        {
                            name:'Текущий счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Текущий счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Текущий счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ],
                metallAccounts:[
                        {
                            name:'Металлический счет',
                            currency: 'Au',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        }
                    ],
                brockAccounts:[
                        {
                            name:'Брокерский счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Брокерский счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                        {
                            name:'Брокерский счет',
                            currency: 'RUB',
                            marginality: 6.3,
                            open_date: '12.03.2020',
                            amt: 'amt',
                            RUB: 'eqv_rub',
                            USD: 'eqv_usd',
                            EUR: 'eqv_eur',
                            partition: '3.75 %'
                        },
                    ]

                },
            show_found_clients: false,
            mistake: undefined,
            formValue: '',
            currency: 'RUB'
        }}