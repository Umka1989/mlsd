import React from 'react';

function AssetsPortfolio(props){
    return(
        <div>AssetsPortfolio</div>
    )
}

export default AssetsPortfolio;